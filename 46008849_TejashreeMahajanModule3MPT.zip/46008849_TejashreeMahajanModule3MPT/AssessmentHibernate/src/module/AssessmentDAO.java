package module;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class AssessmentDAO {

   public static void main(String[] args ) {
   
      EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "Eclipselink_JPA" );
      
      EntityManager entitymanager = emfactory.createEntityManager( );
      entitymanager.getTransaction( ).begin( );
      
      Assessment ass=new Assessment();
      ass.setEmp_id(46008849);
      ass.setModule1("WEB Basics");
      ass.setModule2("Core java");
      ass.setModule3("Servlet");
      ass.setPLP("Insurance_project");
  
      entitymanager.persist(ass);
      entitymanager.getTransaction( ).commit( );

      entitymanager.close( );
      emfactory.close( );
   }
}

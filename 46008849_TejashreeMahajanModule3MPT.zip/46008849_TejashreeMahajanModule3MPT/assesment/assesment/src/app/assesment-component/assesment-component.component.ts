import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assesment-component',
  templateUrl: './assesment-component.component.html',
  styleUrls: ['./assesment-component.component.css']
})
export class AssesmentComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
